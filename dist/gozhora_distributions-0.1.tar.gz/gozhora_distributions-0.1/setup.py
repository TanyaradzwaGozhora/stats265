from setuptools import setup

setup(name='gozhora_distributions',
      version='0.1',
      description='Gaussian and Binomial distributions',
      packages=['gozhora_distributions'],
      author="Tanyaradzwa Gozhora",
      author_email="tanyaradzwagozhora@gmail.com",
      zip_safe=False)
